Run main.py after editing the input file according to your specifications to get an output of predicted powerplay (first 6 overs) score of any ipl match before the match begins
